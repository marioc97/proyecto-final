//
//  OptionsViewController.swift
//  LoginFB
//
//  Created by Cristian Lopez on 20/11/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit
import FirebaseDatabase





class OptionsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
 
    


    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    var materias = ["Historia", "Español", "Fisica", "Matematicas", "Biologia", "Geografia"]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return materias.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath) as! OptionsTableViewCell
        cell.Name.text = materias[indexPath.row]
        cell.ImagenMateria.image = UIImage(named: materias[indexPath.row] + ".jpg")
        return cell
    } 
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segunda"{
            
            let indexPath = Options.indexPathForSelectedRow
            
            let destino = segue.destination as! ContainerViewController
            destino.vieneDeVistaUno = materias[(indexPath?.row)!] 
        }
    }

    @IBOutlet weak var Options: UITableView!


 
}
